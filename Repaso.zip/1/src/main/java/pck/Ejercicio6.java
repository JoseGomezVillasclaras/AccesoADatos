package pck;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public class Ejercicio6 {

	public static void main(String[] args) {
		  Connection conn = null;

	        try {
	            conn = DriverManager.getConnection("jdbc:mysql://localhost/simulacro", "root", "");

	            // Llamada al procedimiento almacenado
	            CallableStatement cstmt = conn.prepareCall("{call calculaelIVA(?, ?, ?, ?)}");

	            // Configurar parámetros de entrada
	            cstmt.setInt(1, 1500); // Reemplaza 100 con el valor de precio deseado
	            cstmt.setInt(2, 1000);
	            cstmt.setInt(3, 800);
	            cstmt.setInt(4, 200);
	            
	            
	            // Configurar parámetros de salida
	          
	            cstmt.registerOutParameter(2, Types.INTEGER); // descuento
	            cstmt.registerOutParameter(3, Types.INTEGER); // iva
	            cstmt.registerOutParameter(4, Types.INTEGER); // totals

	            // Ejecutar el procedimiento
	            cstmt.execute();

	            // Obtener los resultados
	            int descuento = cstmt.getInt(2);
	            int iva = cstmt.getInt(3);
	            int total = cstmt.getInt(4);
	     
	          
	            System.out.println("Descuento: " + descuento);
	            System.out.println("IVA: " + iva);
	            System.out.println("Total: " + total);

	            conn.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        
	}

}
