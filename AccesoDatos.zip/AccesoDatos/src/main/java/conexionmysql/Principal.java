package conexionmysql;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Principal {

	public static void main(String[] args) {
		Connection conn =null;
		
		PreparedStatement presta =null;
		
		String dropProcedure = "DROP PROCEDURE IF EXIST ObtenerClientes";
		
		String createProcedure ="CREATE PROCEDURE ObtenerClientes()"+
		"BEGIN"+
				"SELECT * FROM clientes;"+
		"END;";
		
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/empresa","root","");
			presta=conn.prepareStatement(createProcedure);
			presta.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}

}
