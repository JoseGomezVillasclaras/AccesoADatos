package pck;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Ejercicio4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;

		String sql = "SELECT * FROM productos";

		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/simulacro", "root", "");
			 stmt = conn.createStatement();
			  stmt.executeQuery(sql);
			  System.out.println("Datos mostrados de la tabla productos");
			conn.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
