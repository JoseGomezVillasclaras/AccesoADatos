package pck;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Ejercicio6 {

	public static void main(String[] args) {
		 Connection conn = null;
	        CallableStatement cstmt = null;

	        try {
	            conn = DriverManager.getConnection("jdbc:mysql://localhost/simulacro", "root", "");

	            // Llamar al procedimiento almacenado
	            cstmt = conn.prepareCall("call calculaelIVA()");

	            // Ejecutar el procedimiento
	            cstmt.execute();

	            // Obtener los resultados si el procedimiento devuelve algo
	            ResultSet rs = cstmt.getResultSet();
	            while (rs.next()) {
	               
	            	String nombre = rs.getString("nombre");
	                String iva = rs.getString("iva");
	                int total = rs.getInt("total");
	                System.out.println( "nombre: " + nombre +  " iva: " + iva + ", "+
	                		" total: " + total);
	            }

	            System.out.println("Procedimiento invocado");

	            conn.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	}

}
