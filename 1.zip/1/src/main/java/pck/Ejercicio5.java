package pck;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Ejercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = null;
        PreparedStatement presta = null; // Cambio de nombre de la variable
        String dropProcedure = "DROP PROCEDURE IF EXISTS calculaelIVA";
        String createProcedure = "CREATE PROCEDURE calculaelIVA(IN precio int,OUT descuento INT , OUT iva INT,OUT total INT)) " +
        
        		
                "BEGIN " +
               "SET descuento = precio-(precio*0.10);"+
                "SET iva =decuento*0.21"+
               "SET total=descuento+iva;"+
                "END$$";

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/simulacro", "root", "");
            
            // Primero, eliminamos el procedimiento si existe
            presta = conn.prepareStatement(dropProcedure);
            presta.executeUpdate();

            // Luego, creamos el procedimiento
            presta = conn.prepareStatement(createProcedure);
            presta.executeUpdate();

            System.out.println("Procedimiento creado");

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}

}
